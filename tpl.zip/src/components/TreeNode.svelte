<script lang="ts">
	export let rules;
	export let elements;

	let [root, ...leaves] = elements;
	console.log(root);
	console.log(leaves);

	
</script>

<div class="p-4">
	
</div>

