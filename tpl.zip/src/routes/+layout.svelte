<script>
	import '../app.css';
</script>

<div class="flex w-full h-24 bg-slate-300">
	<h1 class="block m-auto text-2xl font-bold">
		Бригада #3: Бойко<span class="text-yellow-500">⚡⚡</span>,
		<span class="text-red-500">Горохов❤️</span>
	</h1>
</div>

<div class='px-4'>
	<slot />
</div>
