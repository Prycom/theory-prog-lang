<script lang="ts">

</script>


<h2 class="text-xl font-semibold my-6" ><a href='/laba1' class='hover:outline-dashed'>Лабораторная #1</a></h2>
<h2 class="text-xl font-semibold my-6" ><a href='/laba2' class='hover:outline-dashed'>Лабораторная #2</a></h2>
<h2 class="text-xl font-semibold my-6" ><a href='/laba3' class='hover:outline-dashed'>Лабораторная #3</a></h2>
